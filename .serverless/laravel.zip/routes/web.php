<?php

use Illuminate\Http\Request;
use App\Http\Livewire\TestUpload;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\S3Controller;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\UploadController;
use App\Http\Controllers\FileUploadController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/testUpload', function () {
//     return view('fileupload');
// });

// // Route::post('/upload-file', [UploadController::class, 'uploadFile'])->name('test.upload');
// Route::post('/upload-file', function (Request $request) {
//     $file = $request->file('file');
//     $fileSize = $file->getSize();
//     $chunkSize = 100000; // 100KB

//     // Split the file into smaller chunks
//     for ($i = 0; $i < $fileSize; $i += $chunkSize) {
//         $chunk = file_get_contents($file->getRealPath(), false, null, $i, $chunkSize);
//         // Process the chunk here
//     }

//     return response()->json(['message' => 'Upload complete']);
// })->name('test.upload');

// Route::get('/presigned-url', function () {

//     $var = ['url' => $url, 'headers' => $headers] = Storage::temporaryUploadUrl(
//         'upload',
//         now()->addMinutes(5)
//     );

//     session(['presignedUrl' => $var['url']]);
// });

// Route::get('/test-upload', TestUpload::class);

// Route::post('dropzone/store', [UploadController::class, 'storeDropzone'])->name('dropzone.store');
// Route::post('/upload', [FileUploadController::class, 'upload'])->name('file.upload');
Route::get('/s3', [S3Controller::class, 'index'])->name('s3.store');

Route::get('/s3-list', function() {
    $list = Storage::disk('s3')->allFiles();
});
