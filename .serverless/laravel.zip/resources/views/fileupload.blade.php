<!DOCTYPE html>
<html>

<head>
    <title>File Upload</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body>
    <form action="{{ route('file.upload') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <input type="file" name="file">
        <button type="submit">Upload</button>
    </form>

    <script>
        // Initialize the Amazon Cognito credentials provider
        // AWS.config.region = 'ap-southeast-1'; // Region
        // AWS.config.credentials = new AWS.CognitoIdentityCredentials({
        //     IdentityPoolId: 'ap-southeast-1:51095b76-b6f5-4ba1-8395-75fa38cf442d',
        // });
    </script>
</body>

</html>
