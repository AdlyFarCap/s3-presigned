<?php

namespace App\Http\Controllers;

use App\Services\S3Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FileUploadController extends Controller
{
    public function upload(Request $request, S3Service $s3Service)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'required|file',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 400);
        }

        $fileContent = file_get_contents($request->file('file')->getPathname());
        $fileName = $request->file('file')->getClientOriginalName();
        $contentType = $request->file('file')->getMimeType();

        $presignedUrl = $s3Service->uploadWithPresignedUrl($fileContent, $fileName, $contentType);

        return response()->json(['url' => $presignedUrl], 200);
    }
}
