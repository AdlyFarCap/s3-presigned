<?php

namespace App\Http\Controllers;

use Aws\S3\S3Client;
use Illuminate\Http\Request;
use Aws\S3\Exception\S3Exception;


class UploadController extends Controller
{
    public function index()
    {
        return view('upload');
    }

    public function uploadFile(Request $request)
    {

        // $fileContent = $request->getContent();
        // $fileName = $request->file('fileUpload');
        // // $fileName = $request->query('fileName');
        // $contentType = $request->header('Content-Type');

        // $s3Client = new S3Client([
        //     'version' => 'latest',
        //     'region'  => 'ap-southeast-1',
        //     'credentials' => [
        //         'key'    => 'AKIAQM3PMVQEZFPJYHG4',
        //         'secret' => '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',
        //     ],
        // ]);

        // $uploadId = $s3Client->createMultipartUpload([
        //     'Bucket' => 'laravel-dev-storage-12yeo7f2wllrg',
        //     'Key' => $fileName,
        //     'ContentType' => $contentType
        // ]);

        // $partSize = 1024 * 1024 * 5; // 5MB per chunk
        // $chunks = ceil(strlen($fileContent) / $partSize);
        // $partList = [];

        // for ($i = 0; $i < $chunks; $i++) {
        //     $start = $i * $partSize;
        //     $end = min($start + $partSize, strlen($fileContent));
        //     $part = substr($fileContent, $start, $end - $start);

        //     $uploadPart = $s3Client->uploadPart([
        //         'Bucket' => 'laravel-dev-storage-12yeo7f2wllrg',
        //         'Key' => $fileName,
        //         'UploadId' => $uploadId['UploadId'],
        //         'PartNumber' => $i + 1,
        //         'Body' => $part
        //     ]);

        //     $partList[] = [
        //         'ETag' => $uploadPart['ETag'],
        //         'PartNumber' => $i + 1
        //     ];
        // }

        // $s3Client->completeMultipartUpload([
        //     'Bucket' => 'laravel-dev-storage-12yeo7f2wllrg',
        //     'Key' => $fileName,
        //     'UploadId' => $uploadId['UploadId'],
        //     'MultipartUpload' => ['Parts' => $partList]
        // ]);

        // return response()->json(['message' => 'File uploaded successfully']);


        // Instantiate an S3 client
        $s3 = new S3Client([
            'version' => 'latest',
            'region' => 'ap-southeast-1',
            'credentials' => [
                'key'    => 'AKIAQM3PMVQEZFPJYHG4',
                'secret' => '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',
            ],
        ]);

        // Initiate a multipart upload
        $bucket = 'laravel-dev-storage-12yeo7f2wllrg';
        $key = 'upload/' . $request->file('fileUpload')->getClientOriginalName();
        $source = $request->file('fileUpload');
        try {
            $result = $s3->createMultipartUpload([
                'Bucket' => $bucket,
                'Key' => $key,
            ]);
            $uploadId = $result['UploadId'];

            // Upload parts of the file
            $file = fopen($source, 'rb');
            $partNumber = 1;
            $parts = [];
            while (!feof($file)) {
                $part = fread($file, 5 * 1024 * 1024); // 5 MB per part
                $result = $s3->uploadPart([
                    'Bucket' => $bucket,
                    'Key' => $key,
                    'UploadId' => $uploadId,
                    'PartNumber' => $partNumber,
                    'Body' => $part,
                ]);
                $parts[] = [
                    'PartNumber' => $partNumber,
                    'ETag' => $result['ETag'],
                ];
                $partNumber++;
            }
            fclose($file);

            // Complete the multipart upload
            $s3->completeMultipartUpload([
                'Bucket' => $bucket,
                'Key' => $key,
                'UploadId' => $uploadId,
                'MultipartUpload' => [
                    'Parts' => $parts,
                ],
            ]);

            echo "Upload complete!";
        } catch (S3Exception $e) {
            echo $e->getMessage();
        }
    }

    public function storeDropzone()
    {
        
    }
}
