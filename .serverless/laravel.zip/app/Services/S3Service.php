<?php

namespace App\Services;

use Aws\S3\S3Client;
use Aws\S3\MultipartUploader;
use Aws\Exception\MultipartUploadException;

class S3Service
{
    protected $s3Client;

    public function __construct()
    {
        $this->s3Client = new S3Client([
            'version' => 'latest',
            'region' => env('AWS_DEFAULT_REGION'),
            'credentials' => [
                'key' => env('AWS_ACCESS_KEY_ID'),
                'secret' => env('AWS_SECRET_ACCESS_KEY'),
            ],
        ]);
    }

    public function uploadWithPresignedUrl($fileContent, $fileName, $contentType)
    {
        $bucket = env('AWS_BUCKET');
        $key = uniqid('', true) . '-' . $fileName; // generate a unique key based on the file name

        $cmd = $this->s3Client->getCommand('PutObject', [
            'Bucket' => $bucket,
            'Key' => $key,
            'ContentType' => $contentType,
        ]);

        $request = $this->s3Client->createPresignedRequest($cmd, '+20 minutes');
        $presignedUrl = (string) $request->getUri();

        $uploader = new MultipartUploader($this->s3Client, $fileContent, [
            'bucket' => $bucket,
            'key' => $key,
            'Content-Type' => $contentType,
            'ContentLength' => strlen($fileContent),
            'before_upload' => function (\Aws\Command $command) use ($presignedUrl) {
                $command->getRequest()->setUrl($presignedUrl);
            },
        ]);

        try {
            $result = $uploader->upload();
            return $result['ObjectURL'];
        } catch (MultipartUploadException $e) {
            error_log($e->getMessage());
            return null;
        }
    }
}
