<?php return array (
  'test-upload' => 'App\\Http\\Livewire\\TestUpload',
);